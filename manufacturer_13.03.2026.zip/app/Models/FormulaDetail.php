<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class FormulaDetail extends Model
{
    use HasFactory;

    protected $fillable = [
        'formula_id',
        'raw_material_id',
        'percentage',
        'unit',
    ];

    // 🔗 Formül ilişkisi
    public function formula()
    {
        return $this->belongsTo(Formula::class);
    }

    // 🧪 Ham madde ilişkisi
    public function rawMaterial()
    {
        return $this->belongsTo(RawMaterial::class);
    }

    // 🏭 Üretim sürecindeki detaylar (production_formula_details)
    public function productionDetails()
    {
        return $this->hasMany(ProductionFormulaDetail::class);
    }
}