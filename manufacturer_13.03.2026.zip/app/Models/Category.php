<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{

    protected $fillable = ['name','description'];
    public function questions() { return $this->hasMany(Question::class); }
    public function exams() { return $this->hasMany(Exam::class); }


}
