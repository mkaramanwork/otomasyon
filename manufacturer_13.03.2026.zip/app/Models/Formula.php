<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Formula extends Model
{
    use HasFactory;

    protected $fillable = ['name','type','description','added_by','product_id'];

    // 🔗 Formüle bağlı ham madde detayları
    public function details()
    {
        return $this->hasMany(FormulaDetail::class);
    }

    // 👤 Formülü ekleyen kullanıcı
    public function addedBy()
    {
        return $this->belongsTo(User::class, 'added_by');
    }

    // 🔎 Doğrudan ham maddelere erişim (hasManyThrough)
    public function rawMaterials()
    {
        return $this->hasManyThrough(
            RawMaterial::class,
            FormulaDetail::class,
            'formula_id',
            'id',
            'id',
            'raw_material_id'
        );
    }

    // 📊 Detay sayısı accessor
    public function getDetailsCountAttribute()
    {
        return $this->details()->count();
    }

    // 📌 Aktif formül scope'u
    public function scopeActive($query)
    {
        return $query->where('type', 'aktif');
    }

}