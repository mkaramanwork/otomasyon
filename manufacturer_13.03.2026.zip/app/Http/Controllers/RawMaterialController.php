<?php

namespace App\Http\Controllers;

use App\Models\RawMaterial;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class RawMaterialController extends Controller
{
    public function index()
    {
        $rawMaterials = RawMaterial::with('user')->latest()->get();
        return view('rawmaterials.index', compact('rawMaterials'));
    }

    public function create()
    {
        return view('rawmaterials.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'unit' => 'required|string|max:10',
            'stock_kg' => 'required|numeric|min:0',
        ]);

        RawMaterial::create([
            'name' => $request->name,
            'unit' => $request->unit,
            'stock_kg' => $request->stock_kg,
            'added_by' => Auth::id(),
        ]);

        return redirect()->route('raw-materials.index')->with('success', 'Ham madde başarıyla eklendi.');
    }

    public function edit(RawMaterial $rawMaterial)
    {
        return view('rawmaterials.edit', compact('rawMaterial'));
    }

    public function update(Request $request, RawMaterial $rawMaterial)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'unit' => 'required|string|max:10',
            'stock_kg' => 'required|numeric|min:0',
        ]);

        $rawMaterial->update([
            'name' => $request->name,
            'unit' => $request->unit,
            'stock_kg' => $request->stock_kg,
        ]);

        return redirect()->route('raw-materials.index')->with('success', 'Ham madde güncellendi.');
    }

    public function destroy(RawMaterial $rawMaterial)
    {
        $rawMaterial->delete();
        return redirect()->route('raw-materials.index')->with('success', 'Ham madde silindi.');
    }
}