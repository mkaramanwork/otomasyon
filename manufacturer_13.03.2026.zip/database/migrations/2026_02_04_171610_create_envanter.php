<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
    Schema::create('inventories', function (Blueprint $table) {
        $table->id();
        $table->string('product_code');
        $table->string('product_name');
        $table->enum('type', ['Kimyasal','CRM','Cihaz','Sarf Malzeme','Diğer']);
        $table->string('type_other')->nullable(); // "Diğer" seçilirse buraya el ile giriş yapılacak
        $table->text('description')->nullable();
        $table->timestamps();
    });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('inventories');
    }
};
